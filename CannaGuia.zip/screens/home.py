# screens/home.py — Tela inicial com menu principal do CannaGuia

from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.graphics import Color, Rectangle, RoundedRectangle
from kivy.metrics import dp

from theme import (
    FUNDO_ESCURO, FUNDO_CARD, VERDE_ESCURO, VERDE_PRIMARIO, VERDE_CLARO,
    VERDE_HOVER, TEXTO_BRANCO, TEXTO_CINZA, TEXTO_MUDO, TRANSPARENTE,
)


# Entradas do menu principal: (nome_da_tela, icone, título, subtítulo)
MENU_ITENS = [
    ('cultivo',       '🌱', 'Guia de Cultivo',        'Sementes, fases, colheita e cura'),
    ('canabinoides',  '🔬', 'Canabinoides',            'THC, CBD, terpenos e efeitos'),
    ('consumo',       '💨', 'Métodos de Consumo',      'Vaporização, sublingual, tópico'),
    ('vaporizadores', '🌬️', 'Vaporizadores',           'Tipos, câmaras e como escolher'),
    ('associacoes',   '🏛️', 'Associações',             'Como funciona no Brasil'),
    ('onde_comprar',  '🛒', 'Onde Comprar',            'Produtos, sementes e equipamentos'),
    ('quiz',          '🎯', 'Quiz de Direcionamento',  'Descubra o melhor caminho para você'),
]


class BotaoMenu(Button):
    """Botão de card para cada seção do menu principal."""

    def __init__(self, icone, titulo, subtitulo, **kwargs):
        super().__init__(
            background_color=TRANSPARENTE,
            background_normal='',
            background_down='',
            size_hint_y=None,
            height=dp(88),
            **kwargs,
        )
        # Fundo arredondado via canvas
        with self.canvas.before:
            self._cor_fundo = Color(*FUNDO_CARD)
            self._rect = RoundedRectangle(pos=self.pos, size=self.size, radius=[12])
        self.bind(pos=self._atualizar_canvas, size=self._atualizar_canvas)
        self.bind(state=self._on_state)

        # Layout interno: ícone | textos
        layout = BoxLayout(orientation='horizontal', spacing=dp(12),
                           padding=(dp(14), dp(10)))
        layout.pos = self.pos
        layout.size = self.size
        self.bind(pos=lambda inst, v: setattr(layout, 'pos', v),
                  size=lambda inst, v: setattr(layout, 'size', v))

        lbl_icone = Label(
            text=icone,
            font_size='30sp',
            size_hint=(None, 1),
            width=dp(48),
            halign='center',
            valign='middle',
        )

        col = BoxLayout(orientation='vertical', spacing=dp(2))
        lbl_titulo = Label(
            text=f'[b]{titulo}[/b]',
            markup=True,
            color=TEXTO_BRANCO,
            font_size='15sp',
            halign='left',
            valign='bottom',
        )
        lbl_titulo.bind(size=lambda inst, sz: setattr(inst, 'text_size', sz))

        lbl_sub = Label(
            text=subtitulo,
            color=TEXTO_CINZA,
            font_size='12sp',
            halign='left',
            valign='top',
        )
        lbl_sub.bind(size=lambda inst, sz: setattr(inst, 'text_size', sz))

        col.add_widget(lbl_titulo)
        col.add_widget(lbl_sub)

        seta = Label(
            text='›',
            color=VERDE_CLARO,
            font_size='24sp',
            size_hint=(None, 1),
            width=dp(24),
            halign='center',
            valign='middle',
        )

        layout.add_widget(lbl_icone)
        layout.add_widget(col)
        layout.add_widget(seta)
        self.add_widget(layout)

    def _atualizar_canvas(self, *args):
        self._rect.pos = self.pos
        self._rect.size = self.size

    def _on_state(self, inst, state):
        if state == 'down':
            self._cor_fundo.rgba = VERDE_HOVER
        else:
            self._cor_fundo.rgba = FUNDO_CARD


class TelaHome(Screen):
    """Tela principal com logotipo e menu de navegação."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._construir_ui()

    def _construir_ui(self):
        raiz = BoxLayout(orientation='vertical')

        # Fundo escuro
        with raiz.canvas.before:
            Color(*FUNDO_ESCURO)
            self._bg_rect = Rectangle(pos=raiz.pos, size=raiz.size)
        raiz.bind(pos=lambda i, v: setattr(self._bg_rect, 'pos', v),
                  size=lambda i, v: setattr(self._bg_rect, 'size', v))

        # ── Cabeçalho / Hero ─────────────────────────────────────────────────
        cabec = BoxLayout(
            orientation='horizontal',
            size_hint_y=None,
            height=dp(100),
            padding=(dp(12), dp(10)),
            spacing=dp(10),
        )
        with cabec.canvas.before:
            Color(*VERDE_ESCURO)
            r = Rectangle(pos=cabec.pos, size=cabec.size)
        cabec.bind(pos=lambda i, v: setattr(r, 'pos', v),
                   size=lambda i, v: setattr(r, 'size', v))

        # Folha de cannabis — usa cana.png se existir, senão emoji como fallback
        img_folha = Image(
            source='cana.png',
            size_hint=(None, 1),
            width=dp(80),
            allow_stretch=True,
            keep_ratio=True,
        )

        # Coluna de texto (título + subtítulo)
        col_txt = BoxLayout(orientation='vertical', spacing=dp(2))

        lbl_logo = Label(
            text='[b]CannaGuia[/b]',
            markup=True,
            color=TEXTO_BRANCO,
            font_size='26sp',
            halign='left',
            valign='bottom',
        )
        lbl_logo.bind(size=lambda i, s: setattr(i, 'text_size', s))

        lbl_sub = Label(
            text='Cannabis Medicinal no Brasil',
            color=(0.8, 0.95, 0.8, 1),
            font_size='13sp',
            halign='left',
            valign='top',
        )
        lbl_sub.bind(size=lambda i, s: setattr(i, 'text_size', s))

        col_txt.add_widget(lbl_logo)
        col_txt.add_widget(lbl_sub)

        cabec.add_widget(img_folha)
        cabec.add_widget(col_txt)

        # ── Menu rolável ──────────────────────────────────────────────────────
        scroll = ScrollView(do_scroll_x=False)
        grade = GridLayout(
            cols=1,
            size_hint_y=None,
            padding=(dp(14), dp(14), dp(14), dp(20)),
            spacing=dp(10),
        )
        grade.bind(minimum_height=grade.setter('height'))

        lbl_escolha = Label(
            text='Escolha uma seção:',
            color=TEXTO_CINZA,
            font_size='13sp',
            size_hint_y=None,
            height=dp(28),
            halign='left',
            valign='middle',
        )
        lbl_escolha.bind(size=lambda i, s: setattr(i, 'text_size', s))
        grade.add_widget(lbl_escolha)

        for nome_tela, icone, titulo, subtitulo in MENU_ITENS:
            btn = BotaoMenu(icone, titulo, subtitulo)
            # Capturar nome_tela corretamente com argumento padrão
            btn.bind(on_press=lambda inst, nt=nome_tela: self._navegar(nt))
            grade.add_widget(btn)

        scroll.add_widget(grade)

        # ── Rodapé ────────────────────────────────────────────────────────────
        rodape = BoxLayout(
            orientation='vertical',
            size_hint_y=None,
            height=dp(48),
            padding=(dp(8), dp(4)),
        )
        with rodape.canvas.before:
            Color(0.09, 0.09, 0.09, 1)
            r2 = Rectangle(pos=rodape.pos, size=rodape.size)
        rodape.bind(pos=lambda i, v: setattr(r2, 'pos', v),
                    size=lambda i, v: setattr(r2, 'size', v))

        lbl_aviso = Label(
            text='[color=#FF9800]⚠[/color]  Conteúdo informativo. Não substitui orientação médica.',
            markup=True,
            font_size='11sp',
            color=TEXTO_CINZA,
            halign='center',
            valign='middle',
        )
        lbl_aviso.bind(size=lambda i, s: setattr(i, 'text_size', (s[0] - dp(16), None)))

        lbl_credito = Label(
            text='[color=#3A7D44]Criado por FacincaniTech[/color]  [color=#666666]facincanitech@gmail.com[/color]',
            markup=True,
            font_size='10sp',
            color=TEXTO_MUDO,
            halign='center',
            valign='middle',
        )
        lbl_credito.bind(size=lambda i, s: setattr(i, 'text_size', s))

        rodape.add_widget(lbl_aviso)
        rodape.add_widget(lbl_credito)

        raiz.add_widget(cabec)
        raiz.add_widget(scroll)
        raiz.add_widget(rodape)
        self.add_widget(raiz)

    def _navegar(self, nome_tela):
        self.manager.transition.direction = 'left'
        self.manager.current = nome_tela
